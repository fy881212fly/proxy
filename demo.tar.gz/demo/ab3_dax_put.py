
#
#  Copyright 2010-2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
#  This file is licensed under the Apache License, Version 2.0 (the "License").
#  You may not use this file except in compliance with the License. A copy of
#  the License is located at
# 
#  http://aws.amazon.com/apache2.0/
# 
#  This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
#  CONDITIONS OF ANY KIND, either express or implied. See the License for the
#  specific language governing permissions and limitations under the License.
#
#!/usr/bin/env python3
from __future__ import print_function
import boto3
import os, sys, time
import amazondax
import botocore.session
import json

region = os.environ.get('AWS_DEFAULT_REGION', 'us-west-2')

session = botocore.session.get_session()
#dynamodb = session.create_client('dynamodb', region_name=region) # low-level clien

#######dax://daxdemo2.pywhea.dax-clusters.us-west-2.amazonaws.com
endpoint = "dax://daxdemo2.pywhea.dax-clusters.us-west-2.amazonaws.com"
dax = amazondax.AmazonDaxClient(session, region_name=region, endpoint_url='dax://daxdemo2.pywhea.dax-clusters.us-west-2.amazonaws.com')
#######dax://daxdemo2.pywhea.dax-clusters.us-west-2.amazonaws.com


def dax_put(dax_key, dax_value):
    key_data = dax_key
    value_data = dax_value
    table_name = "ab3demo2"
    params = {
    'TableName': table_name,
    'Item': {
        "key": {'S': key_data},
        "value_data": {'S': value_data}
            }
    }
    dax.put_item(**params)
    
    print("PutItem ({}, {}) suceeded".format(key_data, value_data))

#dax_put(key_data, value_data)    



