import socket
s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)

host=socket.gethostname()
port=7777

#建立连接
s.connect((host,port))


while True:
    messg=input("操作指令: ")
    

    s.send(messg.encode())
    
    print("等待响应")
    
    
    
    #接受 查询请求 并打印 , 多了个b'b'??
    
    query_result = s.recv(1024)
    
    print(query_result)