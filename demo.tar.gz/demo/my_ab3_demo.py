import socket
import boto3
import ab3_dax_put
import ab3_dax_query
import person_pb2
from socketserver import BaseRequestHandler, TCPServer

# Complex functions to fit str to redis format
# 将DDB查询返回value 转换成 redis-cli 支持的byte格式。
#**********************************************#
def encode_redis_packet(*args):
    count_args = len(args)
    res = '*' + str(count_args) + '\r\n'
    for i in range(0, count_args):
        data_len = len(args[i])
        res += '$' + str(data_len) + '\r\n'
        res += args[i] + '\r\n'
    return bytes(res, 'utf8')
#**********************************************#

## 数据接收的处理函数
class EchoHandler(BaseRequestHandler):
    def handle(self):
        print('Got connection from', self.client_address)
        msg = self.request.recv(8192)  # 接收redis-cli 命令
        print("hello")
        print(msg)
        cmd = msg.decode()
        print(cmd)
        cmd_split = cmd.split()  # 拆分输入指令
        ops = cmd_split[2]  # 操作 get or set
        k = cmd_split[0]
        print(k)
        print(ops)
        cmd_get = "GET"
        cmd_set = "SET"


# 对命令进行解析和判断，当前支持set 和 get 操作，对应 DynamoDB putItem 和 getItem

        if ops in cmd_get:
            
            key = cmd_split[4]  # key 
            dax_key = key
            query_result = ab3_dax_query.dax_query(dax_key)  #调用DAX的GET功能
            print(query_result)
            self.request.sendall(encode_redis_packet(query_result))
            #self.request.sendall(encode_redis_packet(query_result))
            #需要将 query result 转换成 下面b' 格式，才能执行反序列化
            
            # 如果是二进制 protobuf
            
            proto_info = b'\x08\x01\x12+\x10X\x1a\nfirst_name"\t\n\x05smash\x10Z"\x08\n\x04hurt\x10X*\x06\x08\xe4\xb5\x18\x10\x02'
            print(proto_info)
            
            def getInfo(wanted_info):
                wanted_id = wanted_info.id
                print("user id:", wanted_id)
                print("user age:", wanted_info.people.age)
                for sco in wanted_info.people.score:
                    print("user scores:",sco)
                    
                return str(wanted_id)
                
                #return str(wanted_id), str(wanted_info.people.age), str(sco) 尚且无法返回所有，需要改进

            first_parsed = person_pb2.one()
            first_parsed.ParseFromString(proto_info)
            # print(first_parsed)
            resp = getInfo(first_parsed)
            print("hello")
            print(resp)
                    
            

  
        #将二进制转换成可读的格式并打印
            
        elif ops in cmd_set:

            key = cmd_split[4]  # key 
            value = cmd_split[6]  # value
            dax_key = key
            dax_value = value
            ab3_dax_put.dax_put(dax_key, dax_value)  #调用DAX的SET功能
            
            self.request.sendall(encode_redis_packet("OK"))



# 创建TCP server 监听 xxxxx 端口

if __name__ == '__main__':
    serv = TCPServer(('', 6381), EchoHandler)
    serv.serve_forever()