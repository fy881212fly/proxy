#!/usr/bin/env python3
from __future__ import print_function
import boto3
import os, sys, time
import amazondax
import botocore.session
import json

region = os.environ.get('AWS_DEFAULT_REGION', 'us-west-2')


session = botocore.session.get_session()
#dynamodb = session.create_client('dynamodb', region_name=region) # low-level clien

#######dax://daxdemo2.pywhea.dax-clusters.us-west-2.amazonaws.com
endpoint = "dax://daxdemo2.pywhea.dax-clusters.us-west-2.amazonaws.com"
dax = amazondax.AmazonDaxClient(session, region_name=region, endpoint_url='dax://daxdemo2.pywhea.dax-clusters.us-west-2.amazonaws.com')
#######dax://daxdemo2.pywhea.dax-clusters.us-west-2.amazonaws.com


# Get 对象解析 
def dax_query(dax_key):
    
    key_data = dax_key
#   value_data = dax_value
    table_name = "ab3demo2"
    
    params = {
            'TableName': table_name,
            'Key': {
                "key": {'S': key_data}
                    }
             }
   

    #######
    response = dax.get_item(**params)
    #######
   
   
    #response = dynamodb.get_item(**params)
    
    if 'Item' not in response:
        print("nil")
        return("nil")
        
    else:
        print(response['Item']['value_data']['S'])
        
        # 提取 value_data 字段
        query_result = response['Item']['value_data']['S']
        return query_result
    
