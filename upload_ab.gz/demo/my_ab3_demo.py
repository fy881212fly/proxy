import socket
import boto3
import ab3_dax_put
import ab3_dax_query
import person_pb2
import multiprocessing
import threading
import time
from socketserver import ThreadingTCPServer
from socketserver import BaseRequestHandler, TCPServer
import hashlib
from queue import Queue

s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
s.bind(('',6380))
s.listen(5)

buff = {}

is_exit = False

def msg_handler():
    print("start msg_th")
    while not is_exit:
        time.sleep(0.001)
        for ip_addr in buff.keys(): 
            lock.acquire()  # 加锁  
            if buff[ip_addr].qsize == 0:
                lock.release()  # 释放锁
                continue
            msg = buff[ip_addr].get()
            lock.release()  # 释放锁
            if len(msg) == 0:
                conn.close()
                break
           # conn.send(data.upper())
        #      print(msg)
            cmd = msg.decode()
        #    print(cmd)
        
        
            cmd_split = cmd.split()  # 拆分输入指令
            ops = cmd_split[2]  # 操作 get or set
            k = cmd_split[0]
        
            cmd_get = "GET"
            cmd_set = "SET"
        
        # 对命令进行解析和判断，当前支持set 和 get 操作，对应 DynamoDB putItem 和 getItem
        
            if ops in cmd_get:
                
                key = cmd_split[4]  # key 
                dax_key = key
                query_result = ab3_dax_query.dax_query(dax_key)  #调用DAX的GET功能
        
        
                conn.send(encode_redis_packet(query_result))
        
                #需要将 query result 转换成 下面b' 格式，才能执行反序列化
                
                # 如果是二进制 protobuf
                
                proto_info = b'\x08\x01\x12+\x10X\x1a\nfirst_name"\t\n\x05smash\x10Z"\x08\n\x04hurt\x10X*\x06\x08\xe4\xb5\x18\x10\x02'
                print(proto_info)
                
                def getInfo(wanted_info):
                    wanted_id = wanted_info.id
                    print("user id:", wanted_id)
                    print("user age:", wanted_info.people.age)
                    for sco in wanted_info.people.score:
                        print("user scores:",sco)
                        
                    return str(wanted_id)
                    
                    #return str(wanted_id), str(wanted_info.people.age), str(sco) 尚且无法返回所有，需要改进
        
                first_parsed = person_pb2.one()
                first_parsed.ParseFromString(proto_info)
                # print(first_parsed)
                resp = getInfo(first_parsed)
                print("hello")
                print(resp)
                        
                

            #将二进制转换成可读的格式并打印
                
            elif ops in cmd_set:
        
                key = cmd_split[4]  # key 
                value = cmd_split[6]  # value
                dax_key = key
                dax_value = value
                ab3_dax_put.dax_put(dax_key, dax_value)  #调用DAX的SET功能
                
                
                conn.send(encode_redis_packet("OK"))
                #self.request.sendall(encode_redis_packet("OK"))
        
        # Complex functions to fit str to redis format
        # 将DDB查询返回value 转换成 redis-cli 支持的byte格式。
        #**********************************************#


def action(conn):
     while True:
        msg=conn.recv(1024)
        hash_object = hashlib.md5(str(conn).encode())
        hash_str = hash_object.hexdigest()
        
        lock.acquire()  # 加锁
        buff.setdefault(hash_str, Queue(maxsize=0))
        buff[hash_str].put(msg)
        lock.release()  # 释放锁

def encode_redis_packet(*args):
    count_args = len(args)
    res = '*' + str(count_args) + '\r\n'
    for i in range(0, count_args):
        data_len = len(args[i])
        res += '$' + str(data_len) + '\r\n'
        res += args[i] + '\r\n'
    return bytes(res, 'utf8')
#**********************************************#

## 数据接收的处理函数


# 创建TCP server 监听 xxxxx 端口

if __name__ == '__main__':
#   while True:
    conn,addr=s.accept()
    lock = threading.Lock()  # 获得线程锁
    msg_th = threading.Thread(target=msg_handler)
    msg_th.start()

    for i in range(100):
        th = threading.Thread(target=action,args=(conn,))
    th.start()
    
