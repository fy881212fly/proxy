
#!/usr/bin/env python3
from __future__ import print_function
import boto3
import os, sys, time
import amazondax
import botocore.session
import json
from datetime import datetime

client = boto3.client('dynamodb')

region = os.environ.get('AWS_DEFAULT_REGION', 'us-west-2')


session = botocore.session.get_session()

while True: 
    session = botocore.session.get_session()
    dynamodb = session.create_client('dynamodb', region_name=region) # low-level client

    response = client.describe_table(
        TableName='Music'
    )

    if response['Table']['TableStatus'] in 'ACTIVE':
         print("active")    
    else:
         print("killed")
         os.system('sudo kill 30942')
        