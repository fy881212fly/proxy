import ab3_dax_put
import ab3_dax_query
import random
import string

dax_key = random.choice('abcdefghijklmnopqrstuvwxyz!@#$%^&*()')
dax_value = random.choice('abcdefghijklmnopqrstuvwxyz!@#$%^&*()')

for i in range(1000):
    ab3_dax_put.dax_put(dax_key, dax_value)
    