
#
#  Copyright 2010-2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
#  This file is licensed under the Apache License, Version 2.0 (the "License").
#  You may not use this file except in compliance with the License. A copy of
#  the License is located at
# 
#  http://aws.amazon.com/apache2.0/
# 
#  This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
#  CONDITIONS OF ANY KIND, either express or implied. See the License for the
#  specific language governing permissions and limitations under the License.
#
#!/usr/bin/env python3
from __future__ import print_function
import boto3
import os, sys, time
import amazondax
import botocore.session
import json
from datetime import datetime

region = os.environ.get('AWS_DEFAULT_REGION', 'us-west-2')

#连接复用，放在主函数，线程池
session = botocore.session.get_session()
dynamodb = session.create_client('dynamodb', region_name=region) # low-level client


response = dynamodb.restore_table_to_point_in_time(
#    SourceTableArn='arn:aws:dynamodb:us-west-2:767079860675:table/ab3demo2',
    SourceTableName='ab3demo2',
    TargetTableName='ab3demo3',
    UseLatestRestorableTime=False,
    RestoreDateTime="2021-08-21T07:41:33.769Z",
    BillingModeOverride='PAY_PER_REQUEST',
)


print(response)