import socket
import boto3
import ab3_dax_put
import ab3_dax_query

s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)

#s=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM)

#host=socket.gethostname()
host="127.0.0.1"
port=6666

s.bind((host,port))
s.listen(128)

#接受连接
con,addr=s.accept()
print("connected with",addr)

while True:
    print("等待指令")
    
    s_messg=con.recv(1024)
    
    print("收到指令: ",s_messg.decode())
    
    # 转译DAX 操作
    cmd = s_messg.decode()
    cmd_split = cmd.split() # 拆分输入指令
    
    ops = cmd_split[0]  # 操作 get or set

  #  print(ops)
    
    cmd_get = "get"
    cmd_set = "set"
    
    if   (ops == cmd_get):
        
  #      print("get") 
        key =   cmd_split[1]  # key 
  #      print(key)
        dax_key = key
   #     print(dax_key)

        query_result = ab3_dax_query.dax_query(dax_key)  #调用DAX的GET功能
     #   print(query_result)
  #      print(query_result)
   #     s.send(query_result.encode())
        con.send(query_result.encode()) # 如何返回啊？？？？？？
        
    elif (ops == cmd_set):
        
  #      print ("set")
        key =   cmd_split[1]  # key 
        value = cmd_split[2]  # value
  #      print(key)
  #      print(value)
        
        dax_key = key
        dax_value = value
        
  #      print(dax_key)
  #      print(dax_value)
        ab3_dax_put.dax_put(dax_key, dax_value)  #调用DAX的SET功能

