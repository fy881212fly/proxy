import asyncio
import aioboto3
from boto3.dynamodb.conditions import Key


async def main():
    session = aioboto3.Session()
    async with session.resource('dynamodb', region_name='us-west-2') as dynamo_resource:
        table = await dynamo_resource.Table('ab3demo2')
        
        response = await table.put_item(
            Item={
      
        "key": {'M': 'a'},
        "value_data": {'M': 'vb'}
            
            }
        )

loop = asyncio.get_event_loop()
loop.run_until_complete(main())

