
#coding=utf-8
# file: test_proto.py

import person_pb2

#    def setInfo(a_info):
#        a_info.id = 1
#        a_person = a_info.people
#        a_person.age = 88
#        a_person.name = "first_name"
#        score1 = a_person.score.add()
#        score1.object = "smash"
#        score1.score = 90
#        score2= a_person.score.add()
#        score2.object = "hurt"
#        score2.score = 88
#    
#        # print(a_info)
#        return a_info
#    
#    first_info = person_pb2.one()
#    
#    one_info = setInfo(first_info)
#    
#    print(one_info)
#    
#    proto_info = one_info.SerializeToString()

# proto_info = "b\x08\x01\x12+\x10X\x1a\nfirst_name\"\n\n\x06python\x10Z\"\x07\n\x03c++\x10X*\x06\x08\xe4\xb5\x18\x10\x02" 错误
# 格式转换

proto_info = b'\x08\x01\x12+\x10X\x1a\nfirst_name"\t\n\x05smash\x10Z"\x08\n\x04hurt\x10X*\x06\x08\xe4\xb5\x18\x10\x02'
print(proto_info)

def getInfo(wanted_info):
    wanted_id = wanted_info.id
    print("user id:", wanted_id)
    print("user age:", wanted_info.people.age)
    for sco in wanted_info.people.score:
        print("user scores:",sco)


first_parsed = person_pb2.one()
first_parsed.ParseFromString(proto_info)
# print(first_parsed)
getInfo(first_parsed)
